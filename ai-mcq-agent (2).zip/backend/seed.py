"""
seed.py
--------
One-time script that populates the database with the same questions used
in the Stage 2 frontend mock (js/quiz.js), so the real API has something to
serve immediately. Run this once after creating the database:

    python seed.py

Safe to re-run: it skips subjects that already exist.
"""

from database import SessionLocal, Base, engine
import models

Base.metadata.create_all(bind=engine)

SUBJECTS = {
    "java": "Java",
    "dbms": "DBMS",
    "os": "Operating Systems",
    "sql": "SQL",
}

# (question_text, [option_a, option_b, option_c, option_d], correct_index, explanation, difficulty)
QUESTIONS = {
    "java": [
        ("Which keyword allows a subclass to call a constructor of its superclass?",
         ["this()", "super()", "extends", "base()"], 1,
         "super() invokes the superclass constructor; this() invokes another constructor in the same class.", "medium"),
        ("What is the default value of a boolean instance variable in Java?",
         ["true", "false", "null", "0"], 1,
         "Uninitialized boolean fields default to false; only reference types default to null.", "easy"),
        ("Which collection does NOT allow duplicate elements?",
         ["ArrayList", "LinkedList", "HashSet", "Vector"], 2,
         "Set implementations like HashSet enforce uniqueness; List implementations allow duplicates.", "easy"),
        ("What does the 'final' keyword do when applied to a method?",
         ["Makes it static", "Prevents overriding in subclasses", "Prevents overloading", "Makes it private"], 1,
         "A final method cannot be overridden by subclasses, though it can still be overloaded.", "medium"),
        ("Which exception is thrown when dividing an integer by zero in Java?",
         ["NullPointerException", "NumberFormatException", "ArithmeticException", "ArrayIndexOutOfBoundsException"], 2,
         "Integer division by zero throws ArithmeticException; floating-point division by zero yields Infinity instead.", "easy"),
        ("What is method overloading?",
         ["Same method name, different implementation in a subclass", "Same method name, different parameter lists in the same class", "Calling a method recursively", "Hiding a static method"], 1,
         "Overloading means multiple methods share a name but differ in parameter type/count within the same class.", "medium"),
        ("Which of these is true about an abstract class in Java?",
         ["It cannot have any constructors", "It can have both abstract and concrete methods", "It must be final", "It cannot be extended"], 1,
         "Abstract classes can mix abstract method declarations with fully implemented methods and constructors.", "medium"),
        ("What does the 'volatile' keyword guarantee?",
         ["Thread-safety for compound operations", "Visibility of changes across threads", "Atomicity of increments", "Faster execution"], 1,
         "volatile ensures visibility of the latest value across threads but does not make compound operations atomic.", "hard"),
        ("Which interface must a class implement to be used in a for-each loop?",
         ["Comparable", "Iterable", "Cloneable", "Serializable"], 1,
         "Iterable provides the iterator() method that the enhanced for-loop relies on.", "medium"),
        ("What happens if you don't provide a constructor in a Java class?",
         ["Compilation fails", "The compiler supplies a no-argument default constructor", "The class becomes abstract", "All fields become static"], 1,
         "The compiler automatically inserts a public no-arg constructor if none is defined.", "easy"),
    ],
    "dbms": [
        ("Which normal form eliminates transitive dependency?",
         ["1NF", "2NF", "3NF", "BCNF"], 2,
         "3NF removes transitive dependencies — non-key attributes depending on other non-key attributes.", "medium"),
        ("What does ACID stand for in the context of transactions?",
         ["Atomicity, Consistency, Isolation, Durability", "Accuracy, Concurrency, Integrity, Design", "Atomicity, Concurrency, Isolation, Design", "Accuracy, Consistency, Integrity, Durability"], 0,
         "ACID properties guarantee reliable transaction processing even under failures or concurrent access.", "easy"),
        ("Which type of join returns all rows from both tables, matching where possible?",
         ["INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "FULL OUTER JOIN"], 3,
         "FULL OUTER JOIN returns matched rows plus unmatched rows from both sides, filling missing values with NULL.", "medium"),
        ("What is a primary key?",
         ["Any column with unique values", "A column that references another table", "A minimal set of columns that uniquely identifies each row", "The first column in a table"], 2,
         "A primary key is a minimal, unique identifier for rows and cannot contain NULLs.", "easy"),
        ("Which index type is most suitable for range queries on a sorted column?",
         ["Hash index", "B-Tree index", "Bitmap index", "Full-text index"], 1,
         "B-Tree indexes keep data ordered, making range queries efficient compared to hash indexes.", "hard"),
    ],
    "os": [
        ("Which scheduling algorithm can cause starvation of long processes?",
         ["First-Come-First-Served", "Round Robin", "Shortest Job First", "FCFS with aging"], 2,
         "SJF can starve long processes indefinitely if shorter jobs keep arriving.", "medium"),
        ("What is a deadlock?",
         ["A process using 100% CPU", "A set of processes each waiting for a resource held by another in the set", "A memory leak", "A crashed process"], 1,
         "Deadlock occurs when processes form a cycle of resource dependencies with none able to proceed.", "easy"),
        ("Which of these is NOT one of the four necessary conditions for deadlock?",
         ["Mutual exclusion", "Hold and wait", "Preemption", "Circular wait"], 2,
         "Deadlock requires no preemption, not preemption — resources can't be forcibly taken from a process.", "hard"),
        ("What does paging solve?",
         ["CPU scheduling fairness", "External fragmentation of memory", "Disk read speed", "Process priority inversion"], 1,
         "Paging divides memory into fixed-size frames, eliminating external fragmentation.", "medium"),
    ],
    "sql": [
        ("Which clause filters groups after GROUP BY has been applied?",
         ["WHERE", "HAVING", "FILTER", "ON"], 1,
         "HAVING filters aggregated groups, while WHERE filters rows before aggregation.", "easy"),
        ("What does a subquery in the WHERE clause typically do?",
         ["Sorts results", "Provides a dynamic value or set for comparison", "Creates a new table", "Deletes rows"], 1,
         "A subquery computes a value or set on the fly for the outer query to compare against.", "medium"),
        ("Which SQL keyword removes duplicate rows from a result set?",
         ["UNIQUE", "DISTINCT", "ONLY", "FILTER"], 1,
         "DISTINCT collapses duplicate rows in the query output.", "easy"),
    ],
}


def seed():
    db = SessionLocal()
    try:
        for slug, name in SUBJECTS.items():
            existing = db.query(models.Subject).filter(models.Subject.slug == slug).first()
            if existing:
                print(f"Skipping '{name}' — already seeded.")
                continue

            subject = models.Subject(name=name, slug=slug, description=f"{name} practice questions")
            db.add(subject)
            db.commit()
            db.refresh(subject)

            for text, options, correct_index, explanation, difficulty in QUESTIONS.get(slug, []):
                question = models.Question(
                    subject_id=subject.id,
                    text=text,
                    difficulty=difficulty,
                    explanation=explanation,
                    correct_option_index=correct_index,
                    source="manual",
                )
                db.add(question)
                db.commit()
                db.refresh(question)

                for position, option_text in enumerate(options):
                    db.add(models.Option(question_id=question.id, position=position, text=option_text))
                db.commit()

            print(f"Seeded '{name}' with {len(QUESTIONS.get(slug, []))} questions.")

        print("Done.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
