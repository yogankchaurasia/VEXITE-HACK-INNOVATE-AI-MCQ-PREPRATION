"""
routes/questions.py
---------------------
Read-only endpoints for browsing subjects and topics.
Question CRUD for the admin panel gets added here in Stage 12.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from database import get_db
import models
import schemas

router = APIRouter()


@router.get("/subjects", response_model=List[schemas.SubjectOut])
def list_subjects(db: Session = Depends(get_db)):
    return db.query(models.Subject).order_by(models.Subject.name).all()


@router.get("/topics", response_model=List[schemas.TopicOut])
def list_topics(subject_slug: str, db: Session = Depends(get_db)):
    subject = db.query(models.Subject).filter(models.Subject.slug == subject_slug).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")
    return db.query(models.Topic).filter(models.Topic.subject_id == subject.id).order_by(models.Topic.name).all()
