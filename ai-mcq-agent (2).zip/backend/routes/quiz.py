"""
routes/quiz.py
----------------
POST /quiz/start   -> picks questions from the DB, creates a QuizAttempt, returns
                       questions WITHOUT correct answers.
POST /quiz/submit  -> grades the attempt, stores QuizAnswers + Score, returns a
                       full review (now safe to reveal correct answers).
GET  /quiz/results/{attempt_id} -> re-fetch a previously graded attempt.

user_id is not attached yet — Stage 6 (auth) will add `Depends(get_current_user)`
and set QuizAttempt.user_id from the logged-in user instead of leaving it null.
"""

import random
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from database import get_db
import models
import schemas

router = APIRouter()


@router.post("/quiz/start", response_model=schemas.QuizStartResponse)
def start_quiz(payload: schemas.QuizStartRequest, db: Session = Depends(get_db)):
    subject = db.query(models.Subject).filter(models.Subject.slug == payload.subject_slug).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    query = db.query(models.Question).filter(models.Question.subject_id == subject.id)
    if payload.topic_id:
        query = query.filter(models.Question.topic_id == payload.topic_id)
    if payload.difficulty != "mixed":
        query = query.filter(models.Question.difficulty == payload.difficulty)

    pool = query.all()
    if not pool:
        raise HTTPException(status_code=404, detail="No questions available for this selection yet")

    random.shuffle(pool)
    # Allow repeats if the pool is smaller than requested, same as the Stage 2 mock behavior.
    selected = [pool[i % len(pool)] for i in range(payload.num_questions)]

    attempt = models.QuizAttempt(
        user_id=None,
        subject_id=subject.id,
        difficulty=payload.difficulty,
        total_questions=len(selected),
        started_at=datetime.utcnow(),
    )
    db.add(attempt)
    db.commit()
    db.refresh(attempt)

    questions_out = [
        schemas.QuestionOut(
            id=question.id,
            text=question.text,
            difficulty=question.difficulty,
            options=[opt.text for opt in question.options],
        )
        for question in selected
    ]

    return schemas.QuizStartResponse(
        attempt_id=attempt.id,
        subject=subject.name,
        difficulty=payload.difficulty,
        questions=questions_out,
    )


@router.post("/quiz/submit", response_model=schemas.QuizSubmitResponse)
def submit_quiz(payload: schemas.QuizSubmitRequest, db: Session = Depends(get_db)):
    attempt = db.query(models.QuizAttempt).filter(models.QuizAttempt.id == payload.attempt_id).first()
    if not attempt:
        raise HTTPException(status_code=404, detail="Quiz attempt not found")

    correct_count = 0
    incorrect_count = 0
    unanswered_count = 0
    review: List[schemas.QuestionReview] = []

    for submitted in payload.answers:
        question = db.query(models.Question).filter(models.Question.id == submitted.question_id).first()
        if not question:
            continue

        is_correct = submitted.selected_option_index == question.correct_option_index
        if submitted.selected_option_index is None:
            unanswered_count += 1
        elif is_correct:
            correct_count += 1
        else:
            incorrect_count += 1

        answer_row = models.QuizAnswer(
            attempt_id=attempt.id,
            question_id=question.id,
            selected_option_index=submitted.selected_option_index,
            is_correct=is_correct,
        )
        db.add(answer_row)

        review.append(schemas.QuestionReview(
            id=question.id,
            text=question.text,
            options=[opt.text for opt in question.options],
            correct_option_index=question.correct_option_index,
            explanation=question.explanation,
            selected_option_index=submitted.selected_option_index,
            is_correct=is_correct,
        ))

    total = attempt.total_questions
    percentage = round((correct_count / total) * 100, 1) if total else 0.0
    answered = correct_count + incorrect_count
    accuracy = round((correct_count / answered) * 100, 1) if answered else 0.0

    attempt.correct_count = correct_count
    attempt.incorrect_count = incorrect_count
    attempt.unanswered_count = unanswered_count
    attempt.time_taken_seconds = payload.time_taken_seconds
    attempt.completed_at = datetime.utcnow()

    score_row = models.Score(attempt_id=attempt.id, percentage=percentage, accuracy=accuracy)
    db.add(score_row)
    db.commit()

    return schemas.QuizSubmitResponse(
        attempt_id=attempt.id,
        total_questions=total,
        correct_count=correct_count,
        incorrect_count=incorrect_count,
        unanswered_count=unanswered_count,
        percentage=percentage,
        accuracy=accuracy,
        time_taken_seconds=payload.time_taken_seconds,
        review=review,
    )


@router.get("/quiz/results/{attempt_id}", response_model=schemas.QuizSubmitResponse)
def get_results(attempt_id: int, db: Session = Depends(get_db)):
    attempt = db.query(models.QuizAttempt).filter(models.QuizAttempt.id == attempt_id).first()
    if not attempt or not attempt.score:
        raise HTTPException(status_code=404, detail="Result not found — quiz may not be submitted yet")

    review = []
    for answer in attempt.answers:
        question = answer.question
        review.append(schemas.QuestionReview(
            id=question.id,
            text=question.text,
            options=[opt.text for opt in question.options],
            correct_option_index=question.correct_option_index,
            explanation=question.explanation,
            selected_option_index=answer.selected_option_index,
            is_correct=answer.is_correct,
        ))

    return schemas.QuizSubmitResponse(
        attempt_id=attempt.id,
        total_questions=attempt.total_questions,
        correct_count=attempt.correct_count,
        incorrect_count=attempt.incorrect_count,
        unanswered_count=attempt.unanswered_count,
        percentage=attempt.score.percentage,
        accuracy=attempt.score.accuracy,
        time_taken_seconds=attempt.time_taken_seconds,
        review=review,
    )
