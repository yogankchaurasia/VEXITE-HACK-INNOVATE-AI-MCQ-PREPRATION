"""
schemas.py
-----------
Pydantic models used to validate request bodies and shape response JSON.
Keeping these separate from models.py (the DB tables) is deliberate:
it lets the API shape evolve independently of the database structure.
"""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


# ---------- Subjects & Topics ----------

class TopicOut(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class SubjectOut(BaseModel):
    id: int
    name: str
    slug: str
    description: Optional[str] = None

    class Config:
        from_attributes = True


# ---------- Questions ----------

class QuestionOut(BaseModel):
    """What the frontend receives when starting a quiz — no correct_option_index."""
    id: int
    text: str
    difficulty: str
    options: List[str]

    class Config:
        from_attributes = True


class QuestionReview(BaseModel):
    """Used only after submission, when it's safe to reveal the answer."""
    id: int
    text: str
    options: List[str]
    correct_option_index: int
    explanation: str
    selected_option_index: Optional[int] = None
    is_correct: bool


# ---------- Quiz start ----------

class QuizStartRequest(BaseModel):
    subject_slug: str
    difficulty: str = Field(pattern="^(easy|medium|hard|mixed)$")
    num_questions: int = Field(ge=1, le=50)
    topic_id: Optional[int] = None


class QuizStartResponse(BaseModel):
    attempt_id: int
    subject: str
    difficulty: str
    questions: List[QuestionOut]


# ---------- Quiz submit ----------

class SubmittedAnswer(BaseModel):
    question_id: int
    selected_option_index: Optional[int] = None  # None = left unanswered


class QuizSubmitRequest(BaseModel):
    attempt_id: int
    answers: List[SubmittedAnswer]
    time_taken_seconds: int = 0


class QuizSubmitResponse(BaseModel):
    attempt_id: int
    total_questions: int
    correct_count: int
    incorrect_count: int
    unanswered_count: int
    percentage: float
    accuracy: float
    time_taken_seconds: int
    review: List[QuestionReview]
