"""
main.py
--------
FastAPI application entrypoint.

Run with:
    uvicorn main:app --reload

Then open:
    http://127.0.0.1:8000/docs   (interactive API docs)
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import Base, engine
import models  # noqa: F401 — must be imported so Base.metadata knows about all tables
from routes import questions, quiz

# Creates ai_mcq.db and all tables on first run if they don't exist yet.
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI MCQ Preparation API",
    description="Backend for the AI-powered MCQ preparation app.",
    version="0.1.0",
)

# Allow the static frontend (opened via file:// or a simple http-server) to call this API.
# Tighten this list to your real frontend origin before deploying.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(questions.router, tags=["Subjects & Topics"])
app.include_router(quiz.router, tags=["Quiz"])


@app.get("/")
def root():
    return {"status": "ok", "message": "AI MCQ Preparation API is running. See /docs for endpoints."}
