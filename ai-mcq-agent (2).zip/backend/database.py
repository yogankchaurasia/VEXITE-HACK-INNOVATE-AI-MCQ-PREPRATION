"""
database.py
------------
Sets up the SQLAlchemy engine, session factory, and declarative Base.

Uses SQLite for now (DATABASE_URL in .env). To migrate to PostgreSQL later,
you only need to change DATABASE_URL to something like:
    postgresql://user:password@localhost:5432/ai_mcq_db
No other code in the app needs to change, because everything goes through
this file's `engine` and `SessionLocal`.
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./ai_mcq.db")

# check_same_thread is only needed for SQLite (FastAPI uses multiple threads).
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """
    FastAPI dependency: yields a database session per-request and always
    closes it afterward, even if an error occurs.
    Usage in a route:
        def my_route(db: Session = Depends(get_db)):
            ...
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
