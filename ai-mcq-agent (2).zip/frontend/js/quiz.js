// ---------------------------------------------------------------------------
// quiz.js — Stage 4/5 update: now calls the real FastAPI backend
// (POST /quiz/start, POST /quiz/submit) when it's reachable at API_BASE_URL.
// If the backend isn't running, it falls back to the Stage 2 mock question
// bank below so the page still works standalone.
// ---------------------------------------------------------------------------

const API_BASE_URL = "http://127.0.0.1:8000";
let usingBackend = false;      // set true once /quiz/start succeeds
let currentAttemptId = null;   // returned by the backend when a quiz starts

// ---- Mock question bank -----------------------------------------------
// Structure mirrors what the backend/AI generator will eventually return,
// so swapping the data source later requires no changes to the UI code.
const MOCK_QUESTIONS = {
  java: [
    q("Which keyword allows a subclass to call a constructor of its superclass?",
      ["this()", "super()", "extends", "base()"], 1,
      "super() invokes the superclass constructor; this() invokes another constructor in the same class.", "medium"),
    q("What is the default value of a boolean instance variable in Java?",
      ["true", "false", "null", "0"], 1,
      "Uninitialized boolean fields default to false; only reference types default to null.", "easy"),
    q("Which collection does NOT allow duplicate elements?",
      ["ArrayList", "LinkedList", "HashSet", "Vector"], 2,
      "Set implementations like HashSet enforce uniqueness; List implementations allow duplicates.", "easy"),
    q("What does the 'final' keyword do when applied to a method?",
      ["Makes it static", "Prevents overriding in subclasses", "Prevents overloading", "Makes it private"], 1,
      "A final method cannot be overridden by subclasses, though it can still be overloaded.", "medium"),
    q("Which exception is thrown when dividing an integer by zero in Java?",
      ["NullPointerException", "NumberFormatException", "ArithmeticException", "ArrayIndexOutOfBoundsException"], 2,
      "Integer division by zero throws ArithmeticException; floating-point division by zero yields Infinity instead.", "easy"),
    q("What is method overloading?",
      ["Same method name, different implementation in a subclass", "Same method name, different parameter lists in the same class", "Calling a method recursively", "Hiding a static method"], 1,
      "Overloading means multiple methods share a name but differ in parameter type/count within the same class.", "medium"),
    q("Which of these is true about an abstract class in Java?",
      ["It cannot have any constructors", "It can have both abstract and concrete methods", "It must be final", "It cannot be extended"], 1,
      "Abstract classes can mix abstract method declarations with fully implemented methods and constructors.", "medium"),
    q("What does the 'volatile' keyword guarantee?",
      ["Thread-safety for compound operations", "Visibility of changes across threads", "Atomicity of increments", "Faster execution"], 1,
      "volatile ensures visibility of the latest value across threads but does not make compound operations atomic.", "hard"),
    q("Which interface must a class implement to be used in a for-each loop?",
      ["Comparable", "Iterable", "Cloneable", "Serializable"], 1,
      "Iterable provides the iterator() method that the enhanced for-loop relies on.", "medium"),
    q("What happens if you don't provide a constructor in a Java class?",
      ["Compilation fails", "The compiler supplies a no-argument default constructor", "The class becomes abstract", "All fields become static"], 1,
      "The compiler automatically inserts a public no-arg constructor if none is defined.", "easy"),
  ],
  dbms: [
    q("Which normal form eliminates transitive dependency?",
      ["1NF", "2NF", "3NF", "BCNF"], 2,
      "3NF removes transitive dependencies — non-key attributes depending on other non-key attributes.", "medium"),
    q("What does ACID stand for in the context of transactions?",
      ["Atomicity, Consistency, Isolation, Durability", "Accuracy, Concurrency, Integrity, Design", "Atomicity, Concurrency, Isolation, Design", "Accuracy, Consistency, Integrity, Durability"], 0,
      "ACID properties guarantee reliable transaction processing even under failures or concurrent access.", "easy"),
    q("Which type of join returns all rows from both tables, matching where possible?",
      ["INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "FULL OUTER JOIN"], 3,
      "FULL OUTER JOIN returns matched rows plus unmatched rows from both sides, filling missing values with NULL.", "medium"),
    q("What is a primary key?",
      ["Any column with unique values", "A column that references another table", "A minimal set of columns that uniquely identifies each row", "The first column in a table"], 2,
      "A primary key is a minimal, unique identifier for rows and cannot contain NULLs.", "easy"),
    q("Which index type is most suitable for range queries on a sorted column?",
      ["Hash index", "B-Tree index", "Bitmap index", "Full-text index"], 1,
      "B-Tree indexes keep data ordered, making range queries efficient compared to hash indexes.", "hard"),
  ],
  os: [
    q("Which scheduling algorithm can cause starvation of long processes?",
      ["First-Come-First-Served", "Round Robin", "Shortest Job First", "FCFS with aging"], 2,
      "SJF can starve long processes indefinitely if shorter jobs keep arriving.", "medium"),
    q("What is a deadlock?",
      ["A process using 100% CPU", "A set of processes each waiting for a resource held by another in the set", "A memory leak", "A crashed process"], 1,
      "Deadlock occurs when processes form a cycle of resource dependencies with none able to proceed.", "easy"),
    q("Which of these is NOT one of the four necessary conditions for deadlock?",
      ["Mutual exclusion", "Hold and wait", "Preemption", "Circular wait"], 2,
      "Deadlock requires no preemption, not preemption — resources can't be forcibly taken from a process.", "hard"),
    q("What does paging solve?",
      ["CPU scheduling fairness", "External fragmentation of memory", "Disk read speed", "Process priority inversion"], 1,
      "Paging divides memory into fixed-size frames, eliminating external fragmentation.", "medium"),
  ],
  sql: [
    q("Which clause filters groups after GROUP BY has been applied?",
      ["WHERE", "HAVING", "FILTER", "ON"], 1,
      "HAVING filters aggregated groups, while WHERE filters rows before aggregation.", "easy"),
    q("What does a subquery in the WHERE clause typically do?",
      ["Sorts results", "Provides a dynamic value or set for comparison", "Creates a new table", "Deletes rows"], 1,
      "A subquery computes a value or set on the fly for the outer query to compare against.", "medium"),
    q("Which SQL keyword removes duplicate rows from a result set?",
      ["UNIQUE", "DISTINCT", "ONLY", "FILTER"], 1,
      "DISTINCT collapses duplicate rows in the query output.", "easy"),
  ],
};

function q(text, options, correctIndex, explanation, difficulty) {
  return { text, options, correctIndex, explanation, difficulty };
}

// ---- State ---------------------------------------------------------------
let state = {
  questions: [],       // active question set for this attempt
  answers: [],          // answers[i] = selected option index or null
  currentIndex: 0,
  startTime: null,
  timerInterval: null,
  elapsedSeconds: 0,
  subject: "java",
};

// ---- DOM refs --------------------------------------------------------------
const setupScreen = document.getElementById("setup-screen");
const quizScreen = document.getElementById("quiz-screen");
const resultScreen = document.getElementById("result-screen");
const setupForm = document.getElementById("setup-form");
const subjectSelect = document.getElementById("subject-select");
const difficultySelect = document.getElementById("difficulty-select");
const countSelect = document.getElementById("count-select");
const questionCounter = document.getElementById("question-counter");
const quizSubjectLabel = document.getElementById("quiz-subject-label");
const progressFill = document.getElementById("progress-fill");
const questionText = document.getElementById("question-text");
const optionsList = document.getElementById("options-list");
const prevBtn = document.getElementById("prev-btn");
const nextBtn = document.getElementById("next-btn");
const submitBtn = document.getElementById("submit-btn");
const timerLabel = document.getElementById("quiz-timer");
const reviewList = document.getElementById("review-list");

// ---- Pre-fill subject from ?subject= query param --------------------------
const urlParams = new URLSearchParams(window.location.search);
const preSelectedSubject = urlParams.get("subject");
if (preSelectedSubject && MOCK_QUESTIONS[preSelectedSubject]) {
  subjectSelect.value = preSelectedSubject;
}

// ---- Setup form submit -----------------------------------------------------
setupForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const subject = subjectSelect.value;
  const difficulty = difficultySelect.value;
  const count = parseInt(countSelect.value, 10);
  await startQuiz(subject, difficulty, count);
});

function fetchQuestionsFromMock(subject, difficulty, count) {
  const pool = MOCK_QUESTIONS[subject] || [];
  let filtered = difficulty === "mixed"
    ? pool
    : pool.filter((item) => item.difficulty === difficulty);

  if (filtered.length === 0) filtered = pool; // fall back if a difficulty has no mock items

  // Repeat the pool if the user asked for more questions than we have mocked.
  const result = [];
  for (let i = 0; i < count; i++) {
    result.push({ ...filtered[i % filtered.length], id: null });
  }
  return result;
}

async function fetchQuestionsFromBackend(subject, difficulty, count) {
  const response = await fetch(`${API_BASE_URL}/quiz/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      subject_slug: subject,
      difficulty: difficulty,
      num_questions: count,
    }),
  });

  if (!response.ok) throw new Error(`Backend responded with ${response.status}`);
  const data = await response.json();

  currentAttemptId = data.attempt_id;

  // Normalize to the same shape the mock bank uses. correctIndex/explanation
  // are unknown until /quiz/submit responds — that's the point (don't leak answers).
  return data.questions.map((question) => ({
    id: question.id,
    text: question.text,
    options: question.options,
    difficulty: question.difficulty,
    correctIndex: null,
    explanation: null,
  }));
}

async function startQuiz(subject, difficulty, count) {
  state.subject = subject;
  state.elapsedSeconds = 0;

  try {
    state.questions = await fetchQuestionsFromBackend(subject, difficulty, count);
    usingBackend = true;
  } catch (err) {
    console.warn("Backend unavailable, using mock questions instead:", err.message);
    state.questions = fetchQuestionsFromMock(subject, difficulty, count);
    usingBackend = false;
    currentAttemptId = null;
  }

  state.answers = new Array(state.questions.length).fill(null);
  state.currentIndex = 0;

  setupScreen.classList.add("hidden");
  resultScreen.classList.add("hidden");
  quizScreen.classList.remove("hidden");

  quizSubjectLabel.textContent = subject.toUpperCase() + " · " + difficulty
    + (usingBackend ? "" : " (offline mode)");

  startTimer();
  renderQuestion();
}

// ---- Timer ------------------------------------------------------------
function startTimer() {
  clearInterval(state.timerInterval);
  state.timerInterval = setInterval(() => {
    state.elapsedSeconds++;
    timerLabel.textContent = formatTime(state.elapsedSeconds);
  }, 1000);
}

function stopTimer() {
  clearInterval(state.timerInterval);
}

function formatTime(totalSeconds) {
  const m = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const s = (totalSeconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

// ---- Rendering the current question ----------------------------------
function renderQuestion() {
  const idx = state.currentIndex;
  const question = state.questions[idx];

  questionCounter.textContent = `Question ${idx + 1} of ${state.questions.length}`;
  progressFill.style.width = `${((idx + 1) / state.questions.length) * 100}%`;
  questionText.textContent = question.text;

  optionsList.innerHTML = "";
  question.options.forEach((optionText, optionIndex) => {
    const label = document.createElement("label");
    label.className = "option";
    if (state.answers[idx] === optionIndex) label.classList.add("selected");

    label.innerHTML = `
      <input type="radio" name="option" value="${optionIndex}" ${state.answers[idx] === optionIndex ? "checked" : ""} />
      <span>${optionText}</span>
    `;
    label.addEventListener("click", () => selectOption(idx, optionIndex));
    optionsList.appendChild(label);
  });

  prevBtn.disabled = idx === 0;
  const isLast = idx === state.questions.length - 1;
  nextBtn.classList.toggle("hidden", isLast);
  submitBtn.classList.toggle("hidden", !isLast);
}

function selectOption(questionIndex, optionIndex) {
  state.answers[questionIndex] = optionIndex;
  renderQuestion();
}

prevBtn.addEventListener("click", () => {
  if (state.currentIndex > 0) {
    state.currentIndex--;
    renderQuestion();
  }
});

nextBtn.addEventListener("click", () => {
  if (state.currentIndex < state.questions.length - 1) {
    state.currentIndex++;
    renderQuestion();
  }
});

submitBtn.addEventListener("click", async () => {
  stopTimer();
  if (usingBackend) {
    await submitToBackendAndShowResult();
  } else {
    showResultFromLocalScoring();
  }
});

// ---- Scoring & result screen (offline / mock mode) -----------------------
function showResultFromLocalScoring() {
  quizScreen.classList.add("hidden");
  resultScreen.classList.remove("hidden");

  let correct = 0, incorrect = 0, unanswered = 0;

  state.questions.forEach((question, i) => {
    const given = state.answers[i];
    if (given === null) unanswered++;
    else if (given === question.correctIndex) correct++;
    else incorrect++;
  });

  const total = state.questions.length;
  const percentage = total === 0 ? 0 : Math.round((correct / total) * 100);

  document.getElementById("stat-score").textContent = `${percentage}%`;
  document.getElementById("stat-correct").textContent = correct;
  document.getElementById("stat-incorrect").textContent = incorrect;
  document.getElementById("stat-unanswered").textContent = unanswered;
  document.getElementById("stat-time").textContent = formatTime(state.elapsedSeconds);

  renderReview();
}

// ---- Scoring & result screen (backend mode) -------------------------------
async function submitToBackendAndShowResult() {
  const answers = state.questions.map((question, i) => ({
    question_id: question.id,
    selected_option_index: state.answers[i],
  }));

  try {
    const response = await fetch(`${API_BASE_URL}/quiz/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        attempt_id: currentAttemptId,
        answers,
        time_taken_seconds: state.elapsedSeconds,
      }),
    });
    if (!response.ok) throw new Error(`Backend responded with ${response.status}`);
    const result = await response.json();

    // Fill in correctIndex/explanation now that it's safe to reveal them —
    // this lets Retry / Practice Wrong Questions keep working locally.
    result.review.forEach((reviewItem, i) => {
      state.questions[i].correctIndex = reviewItem.correct_option_index;
      state.questions[i].explanation = reviewItem.explanation;
    });

    quizScreen.classList.add("hidden");
    resultScreen.classList.remove("hidden");

    document.getElementById("stat-score").textContent = `${result.percentage}%`;
    document.getElementById("stat-correct").textContent = result.correct_count;
    document.getElementById("stat-incorrect").textContent = result.incorrect_count;
    document.getElementById("stat-unanswered").textContent = result.unanswered_count;
    document.getElementById("stat-time").textContent = formatTime(result.time_taken_seconds);

    renderReview();
  } catch (err) {
    console.warn("Submit to backend failed, falling back to local scoring:", err.message);
    showResultFromLocalScoring();
  }
}

function renderReview() {
  reviewList.innerHTML = "";
  state.questions.forEach((question, i) => {
    const given = state.answers[i];
    const wasCorrect = given === question.correctIndex;
    const givenText = given === null ? "No answer" : question.options[given];

    const item = document.createElement("div");
    item.className = "review-item";
    item.innerHTML = `
      <p class="review-q">${i + 1}. ${question.text}</p>
      <p class="review-row your-answer ${given === null ? "" : (wasCorrect ? "right" : "wrong")}">Your answer: ${givenText}</p>
      <p class="review-row correct-row">Correct answer: ${question.options[question.correctIndex]}</p>
      <p class="review-explanation">${question.explanation}</p>
    `;
    reviewList.appendChild(item);
  });
}

// ---- Result screen actions -----------------------------------------------
document.getElementById("retry-btn").addEventListener("click", async () => {
  await startQuiz(state.subject, difficultySelect.value, state.questions.length);
});

document.getElementById("practice-wrong-btn").addEventListener("click", () => {
  const wrongQuestions = state.questions.filter((question, i) =>
    state.answers[i] !== question.correctIndex
  );
  if (wrongQuestions.length === 0) {
    alert("No incorrect questions to practice — nice work!");
    return;
  }
  state.questions = wrongQuestions;
  state.answers = new Array(wrongQuestions.length).fill(null);
  state.currentIndex = 0;
  state.elapsedSeconds = 0;

  resultScreen.classList.add("hidden");
  quizScreen.classList.remove("hidden");
  startTimer();
  renderQuestion();
});

document.getElementById("generate-similar-btn").addEventListener("click", () => {
  // Placeholder until Stage 7 (AI MCQ generation) connects this to
  // POST /ai/generate-mcq with the current subject/topic/difficulty.
  alert("AI-generated similar questions will be available once the AI MCQ generator (Stage 7) is connected.");
});
