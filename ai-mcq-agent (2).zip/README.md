# AI MCQ Preparation

An AI-powered MCQ practice app for students. Built in stages — this README covers
everything built so far: the frontend (homepage + quiz) and the backend (FastAPI + SQLite).

## Project structure so far

```
ai-mcq-agent/
├── frontend/
│   ├── index.html
│   ├── quiz.html
│   ├── css/
│   │   ├── style.css
│   │   └── quiz.css
│   └── js/
│       └── quiz.js
├── backend/
│   ├── main.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   ├── seed.py
│   └── routes/
│       ├── questions.py
│       └── quiz.py
├── uploads/
├── chroma_db/
├── .env
├── .env.example
├── .gitignore
└── requirements.txt
```

## 1. Set up the backend (Windows + VS Code)

Open the `ai-mcq-agent` folder in VS Code, then open a terminal (`` Ctrl+` ``) and run:

```powershell
# From the ai-mcq-agent root folder
python -m venv venv
venv\Scripts\activate

pip install -r requirements.txt
```

If `python` isn't recognized, install Python 3.11+ from python.org and make sure
"Add python.exe to PATH" was checked during install, then restart VS Code.

## 2. Configure environment variables

A working `.env` is already included for local development (SQLite, so no setup
needed there). If you ever regenerate it, copy `.env.example` to `.env`.

## 3. Create and seed the database

```powershell
cd backend
python seed.py
```

You should see output like:

```
Seeded 'Java' with 10 questions.
Seeded 'DBMS' with 5 questions.
Seeded 'Operating Systems' with 4 questions.
Seeded 'SQL' with 3 questions.
Done.
```

This creates `ai_mcq.db` (SQLite) in the `backend/` folder with all tables and
sample questions. Re-running `seed.py` is safe — it skips subjects that already exist.

## 4. Run the backend

```powershell
# still inside backend/, with venv active
uvicorn main:app --reload
```

You should see `Uvicorn running on http://127.0.0.1:8000`.

**Test it:**
- Open http://127.0.0.1:8000/docs — Swagger UI where you can try every endpoint.
- Open http://127.0.0.1:8000/subjects — should return a JSON list of 4 subjects.
- In `/docs`, try `POST /quiz/start` with body:
  ```json
  { "subject_slug": "java", "difficulty": "medium", "num_questions": 5 }
  ```
  It should return 5 questions (no correct answers included) and an `attempt_id`.

## 5. Run the frontend against the real backend

Keep `uvicorn` running in one terminal. Then just open `frontend/index.html` in
your browser (double-click it, or use VS Code's "Live Server" extension for
auto-reload). Click **Start Practice** and take a quiz — it now:

1. Calls `POST /quiz/start` to get real questions from SQLite and creates a
   `QuizAttempt` row.
2. Calls `POST /quiz/submit` when you finish, which grades your answers
   server-side, stores a `Score`, and returns the full review with explanations.

If the backend isn't running, the quiz page automatically falls back to the
Stage 2 mock questions (you'll see "(offline mode)" next to the subject name),
so the frontend never breaks on its own.

## What's not built yet

- Login/registration and JWT auth (Stage 6) — quiz attempts currently save with
  no user attached.
- AI question generation, PDF upload, and RAG (Stages 7–9).
- Dashboard, weak-topic detection, personalized study agent (Stages 10–11).
- Admin panel (Stage 12).

Each of those will be added the same way: new route files, new DB tables where
needed, and frontend pages/JS wired to the new endpoints — tested before moving on.
